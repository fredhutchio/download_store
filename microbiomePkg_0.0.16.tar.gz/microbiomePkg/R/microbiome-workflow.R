## generate the man page like this:
## if working directory contains microbiomePkg:
## library(roxygen2)
## roxygenize("microbiomePkg")

.CacheFile <-
    function()
{
    ## FIXME: permanent location in galaxy
    tempfile(sprintf("%s_%s_", "CACHE", Sys.Date()))
}

.OutputFile <-
    function(fileBase="", dir = ".", fileext="")
{
    tempfile(sprintf("%s_%s_", fileBase, Sys.Date()), dir, fileext)
}

##' Input a 'big rectangle' file from a Galaxy pplacer work flow.
##'
##' @title 'pplacer' Galaxy Workflow Data Input
##'
##' @param WorkflowFile Name of the Galaxy pplacer workflow output
##' file.
##' @param MetadataFile Name of the metadata (sample description) file
##' with information corresponding to sample identifiers in the Galaxy
##' pplacer workflow file.
##' @param K The parameters 'K' and 'A' together define a 'K over A'
##' filter. The filter can be used to include only some taxa. The idea
##' is that a taxonomic entity is only included if at least 'A' reads
##' are present in at least 'K' samples. The default is A = K = 0,
##' i.e., include all taxa. Specify 'K' in the box above.
##' @param A Include only taxa with at least K samples greater than A,
##' as described for the parameter K.
##' @param Transform (Optional) A transformation applied to all count
##'    data, after the 'K Over A' filter has been run. Possible values
##'    include "log" (actually, log(x + .5) to avoid logarithms of zero
##'    counts) and "asinh" (inverse hyperboloic sine, a log-like
##'    transformation with better behavior near zero).
##' @param OutputFile Name of output file
##' @importFrom RGalaxy gstop
##' @return character(1); the function creates a file containing an R 
##'     'Community' instance from the 'microbiome' package. The return value
##'     is the Galaxy location in which the object is stored.
workflow <-
    function(WorkflowFile = GalaxyInputFile(),
             SamplesFile = GalaxyInputFile(),
             K = GalaxyNumericParam(0), A = GalaxyNumericParam(0),
             Transform = GalaxyCharacterParam(c("none", "log", "asinh")),
             OutputFile = GalaxyOutput("community", "rda"))
{
    if (length(WorkflowFile) != 1L)
        gstop("'WorkflowFile' must be character(1): %s",
              paste(sQuote(WorkflowFile), collapse=", "))
    if (!file.exists(WorkflowFile))
        gstop("'WorkflowFile' does not exist: %s", sQuote(WorkflowFile))

    if (length(SamplesFile) != 1L)
        gstop("'SamplesFile' must be character(1): %s",
             paste(sQuote(SamplesFile), collapse=", "))
    if (!file.exists(WorkflowFile))
        gstop("'SamplesFile' does not exist: %s", sQuote(SamplesFile))

    KOverA <- c(K, A)
    if (length(KOverA) != 2L || any(is.na(KOverA)))
        gstop("'K' and 'A' must be integers and not NA")

    Transform <- match.arg(Transform)

    counts <- tryCatch({
        conn <- file(WorkflowFile, "r")
        head <- readLines(conn, 3L)
        tail <- readLines(conn)
        counts <- read.csv(textConnection(c(head[1], tail)), header=TRUE,
                           row.names=1)[,-(1:2)]
        close(conn)
        counts
    }, error = function(err) {
        gstop("'read.csv' failed to input WorkflowFile: %s",
             conditionMessage(err))
    })
    samples <- tryCatch({
        read.csv(SamplesFile, row.names=1)
    }, error = function(err) {
        gstop("'read.csv' failed to input SamplesFile: %s",
             conditionMessage(err))
    })

    cc <- tryCatch({
        Community(counts, samples[colnames(counts),, drop=FALSE])
    }, error = function(err) {
        gstop("'Community' instance not created: %s",
             conditionMessage(err))
    })

    ridx <- rowSums(communities(cc) >= KOverA[2]) >= KOverA[1]
    if (sum(ridx) == 0L)
        gstop("'KOverA' removed all rows")
    cc <- cc[ridx,]

    communities(cc) <-
        switch(Transform,
               none = communities(cc),
               log = log(.5 + communities(cc)),
               asinh = asinh(communities(cc)))

    save(cc, file = OutputFile)
    OutputFile
}

.find_duplicate_rownames <-
    function(file, msg)
{
    tryCatch({
        if (length(msg) == 1L && "duplicate 'row.names' are not allowed" == msg)
        {
            lines <- readLines(file)[-1]
            dups <- sapply(strsplit(lines, ","), "[[", 1)
            if (any(duplicated(dups))) {
                dups <- paste(sQuote(unique(dups[duplicated(dups)])),
                              collapse=", ")
                msg <- sprintf("%s; possible duplicates: %s", msg, dups)
            }
        }
    }, error=function(...) NULL)
    msg
}

##' Input a CSV file of integer-valued counts of each taxon (row) in
##' each sample (column), and a CSV file of annotations
##' on each sample. The result is used in down-stream analysis.
##'
##' @title 'Community' Data Input
##' @param CountsFile Name of a CSV file containing OTU samples.
##' @param SamplesFile Name of a CSV file containing sample data.
##' @param K The parameters 'K' and 'A' together define a 'K over A'
##' filter. The filter can be used to include only some taxa. The idea
##' is that a taxonomic entity is only included if at least 'A' reads
##' are present in at least 'K' samples. The default is A = K = 0,
##' i.e., include all taxa. Specify 'K' in the box above.
##' @param A Include only taxa with at least K samples greater than A,
##' as described for the parameter K.
##' @param Transform (Optional) A transformation applied to all count
##'    data, after the 'K Over A' filter has been run. Possible values
##'    include "log" (actually, log(x + .5) to avoid logarithms of zero
##'    counts) and "asinh" (inverse hyperboloic sine, a log-like
##'    transformation with better behavior near zero).
##' @param SampleName (Optional) Samples File column name containing
##' names by which samples are identified in all subsequent
##' calculations. If two rows have the same Sample Name, then
##' corresponding counts in the Counts File are added together.
##' @param ColumnClasses (Optional) Comma-separated names specifying
##' how each column is to be represented. There must be as many names,
##' and in the same order, as there are columns in the file. Typical
##' values include: logical, integer, numeric, character, factor,
##' Date. Use 'factor' to indicate a variable with discrete levels,
##' e.g., sex (with levels Male, Female) tissue type (with levels
##' Tumor, Normal), etc. When 'Date' is used, dates should be
##' formatted consistently as year-month-day or year/month/day, e.g.,
##' 2014-03-26; poorly formed dates will be converted to 'NA' values.
##' @param OutputFile Name of output file
##' @return character(1); the function creates a file containing an R 
##'     'Community' instance from the 'microbiome' package. The return value
##'     is the Galaxy location in which the object is stored.
##' @examples
##' egData <- system.file(package="microbiomePkg", "extdata")
##' counts <- file.path(egData, "bv_counts.csv")
##' samples <- file.path(egData, "bv_samples.csv")
##' ccFile <- community(counts, samples)
##' ccFile
##' @import methods
##' @importMethodsFrom IRanges as.data.frame sapply nrow ncol
##' @importMethodsFrom microbiome communities communities<- normalize
##'   samples trimq
##' @importFrom grDevices dev.off pdf svg colorRampPalette
##' @importFrom microbiome Community dendroribbons cooccurplot pa
##' @importFrom stats as.dendrogram dist hclust median
##'   order.dendrogram reorder
##' @importFrom utils data read.csv write.csv
##' @importFrom RColorBrewer brewer.pal
##' @importFrom lattice trellis.par.set xyplot
##' @export
community <-
    function(CountsFile = GalaxyInputFile(),
             SamplesFile = GalaxyInputFile(),
             K = GalaxyNumericParam(0), A = GalaxyNumericParam(0),
             Transform = GalaxyCharacterParam(c("none", "log", "asinh")),
             SampleName = GalaxyCharacterParam(),
             ColumnClasses = GalaxyCharacterParam(),
             OutputFile = GalaxyOutput("community", "rda"))
{
    if (length(CountsFile) != 1L)
        gstop("'CountsFile' must be character(1): %s",
             paste(sQuote(CountsFile), collapse=", "))
    if (!file.exists(CountsFile))
        gstop("'CountsFile' does not exist: %s", sQuote(CountsFile))

    if (length(SamplesFile) != 1L)
        gstop("'SamplesFile' must be character(1): %s",
             paste(sQuote(SamplesFile), collapse=", "))
    if (!file.exists(SamplesFile))
        gstop("'SamplesFile' does not exist: %s", sQuote(SamplesFile))

    ColumnClasses <- if (length(ColumnClasses) == 0L)
        NA_character_
    else {
        x <- strsplit(ColumnClasses, ", *")[[1]]
        gsub("\\W+", "", x[nzchar(x)])
    }


    KOverA <- c(K, A)
    if (length(KOverA) != 2L || any(is.na(KOverA)))
        gstop("'K' and 'A' must be integers and not NA")

    Transform <- match.arg(Transform)

    counts <- tryCatch({
        read.csv(CountsFile, row.names=1)
    }, error = function(err) {
        msg <- conditionMessage(err)
        msg <- .find_duplicate_rownames(CountsFile, msg)
        gstop("'read.csv' failed to input Counts File: %s", msg)
    })

    samples <- tryCatch({
        read.csv(SamplesFile, row.names=1, colClasses=ColumnClasses)
    }, error = function(err) {
        msg <- conditionMessage(err)
        if (length(msg) == 1L) {
            regexp <- c("^scan\\(\\) expected '.*', got '.*'$",
                '^no method or default for coercing ".*" to "(.*)"$')
            if (grepl(regexp[1], msg))
                msg <-
                    sprintf("likely ColumnClasses inconsistent with data (%s)",
                            msg)
            else if (grepl(regexp[2], msg)) {
                msg <- sprintf("likely mis-specified ColumnClasses name %s (%s)",
                               sQuote(sub(regexp[2], "\\1", msg)), msg)
            }
        }
        gstop("'read.csv' failed to input Samples File: %s", msg)
    })

    bad <- !sapply(counts, is, "numeric")
    if (any(bad)) {
        idx <- which(bad)
        txt <- sprintf("%s (%s); ", names(counts)[idx],
                       sapply(counts, class)[idx])
        gstop("'Counts File' columns must be numeric; bad columns: %s\n", txt)
    }

    if (length(SampleName) != 0L) {
        SampleName <- gsub("\\W+", "", SampleName)
        if (!SampleName %in% names(samples))
            gstop("Sample Name column %s not in Sample File; possible values: %s",
                  sQuote(SampleName),
                  paste(sQuote(names(samples)), collapse=", "))
        id <- as.character(samples[[SampleName]])
        if (any(duplicated(id))) {
            ## FIXME
            gstop("collapsing across runs not yet implemented")
        }
        idx <- match(colnames(counts), rownames(samples))
        colnames(counts)[!is.na(idx)] <- id[idx[!is.na(idx)]]
        rownames(samples) <- id
    } 

    cc <- tryCatch({
        Community(counts, samples)
    }, error = function(err) {
        gstop("'Community' instance not created: %s", conditionMessage(err))
    })

    if (prod(dim(cc)) == 0L)
        gstop("no 'Counts File' column labels consistent with
               'Samples File' row labels")

    ridx <- rowSums(communities(cc) >= KOverA[2]) >= KOverA[1]
    if (sum(ridx) == 0L)
        gstop("'KOverA' removed all rows")
    cc <- cc[ridx,]

    communities(cc) <-
        switch(Transform,
               none = communities(cc),
               log = log(.5 + communities(cc)),
               asinh = asinh(communities(cc)))

    save(cc, file = OutputFile)

    txt <- sprintf("    %s: %s\n", names(samples), sapply(samples, class))
    message("'Sample File' columns:\n", txt)

    OutputFile
}

## utilities for functions operating on CommunityFile

.communityFileInput <-
    function(CommunityFile)
{
    if (length(CommunityFile) != 1L)
        gstop("'CommunityFile' must be character(1): %s",
             paste(sQuote(CommunityFile), collapse=", "))
    if (!file.exists(CommunityFile))
        gstop("'CommunityFile' does not exist: %s",
             sQuote(CommunityFile))

    tryCatch({
        get(load(CommunityFile))
    }, error = function(err) {
        gstop("'CommunityFile' failed to load: %s",
             conditionMessage(err))
    })
}

.attributesInput <-
    function(Attributes, community)
{
    if (length(Attributes) != 1L)
        Attributes <- paste(Attributes, collapse=", ")
    if (nzchar(Attributes)) {
        x <- strsplit(Attributes, ", *")[[1]]
        Attributes <- gsub("\\W+", "", x[nzchar(x)])
    }

    if (length(Attributes) == 1L && !nzchar(Attributes)) {
        Attributes <- names(samples(community))
        if (length(Attributes) == 0L)
            gstop("'CommunityFile' data contains no attributes")
    } else if (!all(ok <- Attributes %in% names(samples(community)))) {
        gstop("'Attribute' not in CommunityFile: %s; possible values: %s",
              paste(sQuote(Attributes[!ok]), collapse=", "),
              paste(sQuote(names(samples(community))),
                collapse=", "))
    }

    Attributes
}

.briefStatistics <-
    function(x) 
{
    c(Median = median(x), Mean = mean(x), Minimum = min(x),
      Maximum = max(x), `Std. Dev.` = sqrt(var(x)))
}

.prints <-
    function(con, ..., title = character(), append.sink=TRUE)
{
    if (length(title))
        cat("\n", paste0(title, collapse="\n"), "\n", file=con,
            sep="")
    sink(con, append.sink)
    on.exit(sink(NULL))
    print(...)
}

.cats <-
    function(con, ..., title = character(), append.sink=TRUE)
{
    if (length(title))
        cat("\n", paste0(title, collapse="\n"), "\n", file=con,
            sep="")
    sink(con, append.sink)
    on.exit(sink(NULL))
    cat(...)
}

.mdsPlots <-
    function(fnm, df, covars, ..., colschm=brewer.pal(9, "OrRd")[3:9],
             pch=19, cex=1.2)
{
    ## FIXME: would like this to be multiple page svg
    pdf(fnm)
    for (group in covars) {
        data <- df[!is.na(df[[group]]),,drop=FALSE]
        grp <- factor(data[[group]])
        len <- length(levels(grp))
        dot <- list(col=colorRampPalette(colschm)(len), pch=pch, cex=cex)
        trellis.par.set(superpose.symbol=dot, dot.symbol=dot)
        print(xyplot(NMDS2~NMDS1, data, group=grp, ..., pch=pch, cex=cex,
                     auto.key=list(columns=len), main=group))
    }
    dev.off()
    fnm
}

.log1 <- function(x) log(1 + x)
    
##' Display available attributes from a community file, for use
##' with other Microbiome Workflow tools.
##'
##' @title Get available attributes from a community file.
##' @param CommunityFile created by the 'community' function.
##' @param OutputFile Name of output file
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' getAttributesList(communityFile)
##' @return character(1); the available attributes
##' @export
getAttributeList <-
  function(CommunityFile=GalaxyInputFile(formatFilter="rda"), 
    OutputFile=GalaxyOutput("attributes", "txt"))
  {
    cc <- .communityFileInput(CommunityFile)
    attributes <- names(samples(cc))
    s <- paste(attributes, collapse=", ")
    cat(s, file=OutputFile)
    attributes
  }

##' Generate descriptive statistics about taxa and samples present in a
##' CommunityFile.
##' 
##' @title Taxonomic and Sample Descriptive Statistics
##' @param CommunityFile File created by the 'community' function.
##' @param Attributes Comma-separated names of SamplesFile columns on
##' which descriptive statistics are to be calculated. Example:
##' Nugent_2_group
##' @param OutputFile Name of output file
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' ds <- descriptiveStatistics(communityFile, "Nugent_2_group")
##' noquote(readLines(ds))
##' @return character(1); a text file containing summary statistics
##' @export
descriptiveStatistics <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             Attributes = GalaxyCharacterParam(),
             OutputFile = GalaxyOutput("descriptiveStatistics", "txt"))
{
    owidth <- options(width=130)
    on.exit(options(width=owidth))
    cc <- .communityFileInput(CommunityFile)
    Attributes <- .attributesInput(Attributes, cc)

    con <- tryCatch({
        file(OutputFile, "wt")
    }, error = function(err) {
        gstop("could not open output file: %s", conditionMessage(err))
    })
    on.exit(close(con))

    cat("Samples:", ncol(cc), "\n", file=con)
    cat("Taxa:", nrow(cc), "\n", file=con)
    counts <-
        rbind(`Taxa per Sample` =
                  .briefStatistics(colSums(communities(cc) > 0)),
              `Reads per Sample (Transformed)` =
                  .briefStatistics(colSums(communities(cc))),
              `Samples per Taxon` =
                  .briefStatistics(rowSums(communities(cc) > 0)),
              `Reads per Taxon (Transformed)` =
                  .briefStatistics(rowSums(communities(cc))))
    .prints(con, counts, title = "Counts:")

    ok <- sapply(samples(cc)[, Attributes, drop=FALSE], is.numeric)
    result <- lapply(samples(cc)[, Attributes[ok], drop=FALSE],
                     summary)
    nms <- unique(unlist(sapply(result, names), use.names=FALSE))
    result <- t(sapply(result, function(r, nms) setNames(r[nms], nms), nms))
    .prints(con, result, title="Attributes (numeric):")

    for (attribute in Attributes[!ok]) {
        attr <- samples(cc)[[attribute]]
        title <- sprintf("Attribute (%s): %s", class(attr), attribute)
        if (is(attr, "character")) {
            value <- sprintf("%s, ...\n",
                             paste(sQuote(head(attr)), collapse=", "))
            .cats(con, value, title=title)
        } else {
            value <- summary(attr)
            .prints(con, value, title = title)
        }
    }

    summary(con)$description
}


##' Compute per-sample Shannon, Simpson, Chao1, and ACE summary
##' statistics of taxonomic diversity. Also report per-sample number
##' of taxa with non-zero read counts, and total number of reads.
##'
##' @title Taxonomic Diversity Statistics
##' @param CommunityFile File created by the 'community' function.
##' @param OutputFile Name of the output file.
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' dstats <- diversityStatistics(communityFile,
##'    GalaxyOutput("diversityStatistics", "txt"))
##' head(read.csv(dstats))
##' @return character(1); a comma-separated value file containing
##' per-sample summaries of taxa, reads, Shannon, Simpson, Chao1 and
##' ACE diversity statistics
##' @export
diversityStatistics <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
      OutputFile = GalaxyOutput("diversityStatistics", "csv"))
{
    cc <- .communityFileInput(CommunityFile)
    stats <- microbiome::diversityStatistics(cc)
    write.csv(signif(stats, 3), file=OutputFile)
    OutputFile
}

##' Summarize samples with each taxon present, grouped by factor
##' 
##' @title Taxonomic Presence / Absence Summary and Chi-squared Test
##' @param CommunityFile File created by the 'community' function
##' @param Attribute Name of a sample attribute to summarize presence
##'  / absence data. Example:
##'  Nugent_2_group
##' @param OutputFile Name of the output file.
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' pa <- presenceAbsence(communityFile, "Nugent_2_group")
##' read.csv(pa)[1:6,]
##' @return character(1); a comma-separated value file containing
##' per-taxon counts, chi-squared statstic, and P-value.
##' @export
presenceAbsence <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             Attribute = GalaxyCharacterParam(),
             OutputFile = GalaxyOutput("presenceAbsence", "csv"))
{
    cc <- .communityFileInput(CommunityFile)
    Attribute <- .attributesInput(Attribute, cc)
    if (length(Attribute) != 1L)
        gstop("'Attribute' must name a single attribute: %s",
             paste(sQuote(Attribute), collpase=", "))

    attr <- mcols(cc)[[Attribute]]
    if (!is.factor(attr) && length(unique(attr)) > 10L)
        gstop("'Attribute' must be a 'factor' or have fewer than
              10 distinct values")

    result <- tryCatch({
        pa(cc, Attribute)
    }, error=function(err) {
        gstop("'Presence/Absence failed: %s", conditionMessage(err))
    })
    df <- as.data.frame(result)
    idx <- seq(ncol(df) - 1L, ncol(df))
    df[idx] <- signif(df[idx], 3)
    colnames(df) <- names(result)       # allow non-mangled names

    write.csv(df, file=OutputFile)
    OutputFile
}

##' Attributes of samples as heat maps, with samples clustered by one
##' of several algorithms
##' 
##' @title Attribute Ribbon Plot of Clustered Samples
##' @param CommunityFile File created by the 'community' function.
##' @param Attributes  Comma-separated names of SamplesFile columns on
##' which ribbons are to be plotted. Samples are ordered by the first
##' element of Attributes; Attributes must identify more than 1
##' SampleFile column. Example:
##' Nugent_3_group, Amsel, Nugent_Lactobacillus, pH, Clue
##' @param ClusteringAlgorithm Algorithm to use for clustering
##' samples, one of "hclust" or 'DirichletMultinomial" (from the
##' DirichletMultinomial package).
##' @param OutputFile Name of the output file, usually with a '.svg'
##' extension.
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' drp <- ribbonPlot(communityFile,
##'     c("Nugent_3_group, Amsel, Nugent_Lactobacillus, pH, Clue"))
##' @return character(1); a scalable vector graphic file containing
##' the ribbon plot
##' @export
ribbonPlot <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             Attributes = GalaxyCharacterParam(),
             ClusteringAlgorithm = 
                GalaxyCharacterParam(c("hclust", "DirichletMultinomial")),
             OutputFile = GalaxyOutput("ribbonPlot", "svg"))
{
    cc <- .communityFileInput(CommunityFile)
    Attributes <- .attributesInput(Attributes, cc)
    ## FIXME: should work when length(Attributes) == 1L
    if (length(Attributes) == 1L)
        gstop("'Attributes' has 1 SampleFile column")

    .mkcluster <-
        function(x, distfun=dist,
                 hclustfun=function(...) hclust(..., method="average"))
    {
        hclustfun(distfun(t(communities(x))))
    }
    
    cc1 <- normalize(trimq(cc, taxonQ=.7))
    ddr <- as.dendrogram(.mkcluster(cc1))

    df <- samples(cc1)[, Attributes, drop=FALSE]
    o <- order(df[[ Attributes[1] ]])
    ddr <- rev(reorder(ddr, o))
    df <- df[order.dendrogram(ddr),, drop=FALSE]

    svg(OutputFile)
    dendroribbons(ddr, df, dheight=.3, dwidth=.65)
    dev.off()
    OutputFile
}

##' Reduce dimensionality of taxonomic abundance.
##'
##' @title Taxnomic Dimensionality Reduction (Ordination) Plot
##' @param CommunityFile File created by the 'community' function.
##' @param Attributes  Comma-separated names of SamplesFile columns on
##' which ribbons are to be plotted. Samples are ordered by the first
##' element of Attributes; Attributes must identify more than 1
##' SampleFile column. Example:
##' Nugent_3_group, Amsel, Nugent_Lactobacillus, pH, Clue
##' @param OrdinationAlgorithm Algorithm to use for oridination "PCoA"
##' (Principle Coordinates Analysis), "NMDS" (Non-Metric
##' Multidimensional Scaling), "CA" (Correspondence Analysis), "DPCoA"
##' (Double Principle Components Analysis).
##' @param OutputFile Name of the output file, usually with a '.pdf'
##' extension.
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' mdsPdf <- reducedDimensionality(communityFile,
##'    "Nugent_2_group, Nugent_3_group")
##' if (interactive()) browseURL(mdsPdf)
##' @importFrom vegan metaMDS scores
##' @return character(1); the name of the PDF file containing the
##' plot(s)
##' @export
reducedDimensionality <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             Attributes = GalaxyCharacterParam(),
             OrdinationAlgorithm = GalaxySelectParam(c("MDS")),
#             OutputFile = GalaxyOutput(DimensionalReductionMethod, "pdf"))
             OutputFile = GalaxyOutput("reducedDimensionality", "pdf"))

{
    cc <- .communityFileInput(CommunityFile)
    Attributes <- .attributesInput(Attributes, cc)
    if (length(Attributes) == 0L)
        gstop("no matching 'Attributes' found")
    attributes <- as.data.frame(samples(cc))[,Attributes,drop=FALSE]
    rownames(attributes) <- colnames(cc)
    result <- switch(match.arg(OrdinationAlgorithm),
        MDS = {
            mds <- metaMDS(t(communities(cc)))
            df <- microbiome:::.mmerge(attributes, as.data.frame(scores(mds)))
            .mdsPlots(OutputFile, df, names(attributes))
        }, gstop("method %s not implemented", sQuote(OrdinationAlgorithm)))
}

##' Taxonomic co-occurrence across samples, displayed as a heatmap.
##'
##' @title Taxonomic Co-occurrence Heatmap
##' @param CommunityFile File created by the 'community' function.
##' @param TaxonQuantile (Optional, default 0) Numeric value between 0
##' and 1, limiting only taxa more frequent than the specified
##' quantile.
##' @param Transform (Optional; default 'none') Character string
##' defining how count data are to be transformed prior to calculation
##' of co-occurrence. Possible values are 'none', 'log1' (log of 1 +
##' the observed count, to allow for zeros in the data), 'asinh' (a
##' log-like transformation that handles zeros more naturally), 'sqrt'
##' (square root, a transformation commonly used for count data).
##' @param OutputFile Name of the output file, usually with extension
##' 'pdf'
##' @return character(1); the name of the PDF file containing the
##' plot
##' @examples
##' communityFile <- system.file("data", "community.rda",
##'     package="microbiomePkg")
##' cooccurrencePdf <- cooccurrence(communityFile, .7, "sqrt")
##' if (interactive()) browseURL(cooccurrencePdf)
##' @export
cooccurrence <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             TaxonQuantile = GalaxyNumericParam(0),
             Transform =
                 GalaxyCharacterParam(c("none", "log1", "asinh", "sqrt")),
             OutputFile = GalaxyOutput("cooccurrence", "pdf"))
{
    if ((length(TaxonQuantile) != 1L) ||
            (TaxonQuantile < 0 || TaxonQuantile > 1))
        gstop("'TaxonQuantile' must a single numeric value between 0 and 1")
    Transform <- switch(match.arg(Transform),
                        none=force, log1=.log1, asinh=asinh, sqrt=sqrt)
    cc <- .communityFileInput(CommunityFile)
    cc1 <- normalize(trimq(cc, taxonQ=TaxonQuantile), transform=Transform)
    pdf(OutputFile)
    cooccurplot(cc1, main=character(), margins=c(10, 10))
    dev.off()
    OutputFile
}

##' Rank abundance plots
##'
##' @title Rank Abundance of Taxonomic Counts
##' @param CommunityFile File created by the 'community' function.
##' @param TaxonQuantile (Optional, default 0) Numeric value between 0
##' and 1, limiting only taxa more frequent than the specified
##' quantile.
##' @param Transform (Optional; default 'none') Character string
##' defining how count data are to be transformed prior to calculation
##' of co-occurrence. Possible values are 'none', 'log1' (log of 1 +
##' the observed count, to allow for zeros in the data), 'asinh' (a
##' log-like transformation that handles zeros more naturally), 'sqrt'
##' (square root, a transformation commonly used for count data).
##' @param RelativeAbundance (Optional, default FALSE) When TRUE,
##' scale transformed taxon abundances of each sample to sum to 1.
##' @param Attributes Provide ribbon(s) identifying samples according
##' to specified attributes.
##' @param OutputFile Name of the output file, usually with the
##' extension 'pdf'
##' @export
rankAbundancePlot <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             TaxonQuantile = GalaxyNumericParam(0),
             Transform =
                 GalaxyCharacterParam(c("none", "log1", "asinh", "sqrt")),
             RelativeAbundance = GalaxyLogicalParam(FALSE),
             Attributes = GalaxyCharacterParam(),
             OutputFile = GalaxyOutput("rankAbundance", "pdf"))
{
    if ((length(TaxonQuantile) != 1L) ||
            (TaxonQuantile < 0 || TaxonQuantile > 1))
        gstop("'TaxonQuantile' must a single numeric value between 0 and 1")
    Transform <- switch(match.arg(Transform), none = force, log1 = .log1, 
        asinh = asinh, sqrt = sqrt)
    
    cc <- .communityFileInput(CommunityFile)
    if (length(Attributes))
        Attributes <- .attributesInput(Attributes, cc)

    cc1 <- normalize(trimq(cc, taxonQ=TaxonQuantile), transform=Transform)

    fill <- rainbow(nrow(cc1))
    m <- communities(cc1)
    pdf(OutputFile, width = 12, height=2 + ncol(cc1) / 10)

    mar0 <- c(10, 0, 0, 0)
    par(mar=mar0)
    if (length(Attributes)) {
        layout(matrix(1:4, nrow=1), widths=c(15, length(Attributes), 30, 15))
    } else {
        layout(matrix(1:3, nrow=1), widths=c(15, 30, 15))
    }

    d <- as.dendrogram(hclust(dist(t(m)), method="average"))
    cidx <- order.dendrogram(d)
    if (!length(Attributes)) {
        par(mar=c(mar0[1:3], 3))
        plot(d, horiz = TRUE, yaxt = "n")
        par(mar=mar0)
    } else  {
        plot(d, horiz = TRUE, yaxt = "n", leaflab="none")
    }

    if (length(Attributes)) {
        ribbons <- sapply(samples(cc1)[cidx, Attributes, drop=FALSE], function(elt) {
            match(elt, sort(unique(elt)))
        })
        ## ribbon
        col <- colorRampPalette(brewer.pal(9, "OrRd")[3:9])(max(ribbons, na.rm=TRUE))
        plot.new()                      # correct bounds
        image(t(ribbons), xaxt="n", yaxt="n", add=TRUE, col=col)
        len <- length(Attributes)
        at <- seq_along(Attributes) / len - .5 / len
        axis(1, at, labels=Attributes, las=3, padj=.5)
    }

    ridx <- order(rowSums(m), decreasing = TRUE)
    m <- m[ridx, cidx]
    if (RelativeAbundance)
        m <- sweep(m, 2, colSums(m, na.rm=TRUE), `/`)
    barplot(m, col = fill, horiz = TRUE, axisnames = FALSE)

    plot.new()
    lbl <- rownames(m)
    legend(0, 1, legend = lbl, fill = fill, bty = "n", ncol = 1,
           yjust=1, adj=c(0, 0),
           title = sprintf("%d Most Abundant Taxa", min(length(lbl), 
             nrow(cc1))))

    dev.off()
    OutputFile
}

##' Generalized linear models of counts as a function of sample
##' attributes.
##' 
##' @title Generalized Linear Model of Taxonomic Counts
##' @param CommunityFile File created by the 'community' function.
##' @param GLMFormula 
##' @param OutputFile Name of the output file.
generalizedLinearModel <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             GLMFormula = GalaxyCharacterParam(),
             Model =
                 GalaxyCharacterParam(c("zeroinfl", "hurdle", "glm.nb")),
             OutputFile = GalaxyOutput("generalizedLinearModel", "csv"))
{
    cc <- .communityFileInput(CommunityFile)
    tryCatch({
        model.matrix(as.formula(GLMFormula),
                     as.data.frame(samples(cc)))
    }, error=function(err) {
        gstop("could not create model matrix, invalid 'GLMFormula'?")
    })
    GLMFormula1 <-
        as.formula(paste("count", as.character(GLMFormula), collapse=" "))
    FUN <- match.fun(match.arg(Model))

    fit1 <- glmFit(GLMFormula1, cc, FUN=FUN)
    anv <- glmSummary(fit1)

    xtnb <- xtabs(GLMFormula1, cc)
    n <- xtabs(GLMFormula, cc)
    xtnb$Mean <- ifelse(n$Freq == 0, 0, xtnb$Freq / n$Freq)
    xtnb$GeomMean <- .log1(ifelse(n$Freq == 0, 0, xtnb$Freq / n$Freq))

    gstop("not yet implemented")
    ## xtnb1 <- with(xtnb, {
    ##     df <- split(GeomMean, list(nugent_2_group, race))
    ##     df <- as(df, "DataFrame")
    ##     rownames(df) <- unique(Name)
    ##     names(df) <-
    ##         as.vector(outer(sub(" .*", "", levels(xtnb[[2]])),
    ##                         sub(" ", "", levels(xtnb[[3]])),
    ##                         paste))
    ##     idx <- match(rownames(anv), rownames(df))
    ##     df[idx,]
    ## })
    ## res <- as.data.frame(cbind(as.data.frame(xtnb1), anv))
    ## res$P.Count.adj <- p.adjust(res$P.Count, method="BH")

    ## write.csv(res, file=OutputFile)
    OutputFile
}

##' Regularized (loess) regression of sample attributes as a function
##' of taxonomic counts
##'
##' @title Regularized Regression of Sample Attributes
##' @param CommunityFile File created by the 'community' function.
##' @param RegularizedModel 
##' @param OutputFile Name of the output file.
regularizedRegression <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             RegularizedModel = 
                GalaxyCharacterParam(c("binomial", "multinomial", "gaussian")),
             OutputFile = GalaxyOutput("notimplemented", "txt"))
{
    gstop("not implemented")
}

##' FIXME
##'
##' @title Unified Work Flow
##' @param CommunityFile File created by the 'community' function.
##' @param Attributes 
##' @param ClusteringAlgorithm 
##' @param DimensionalReductionMethod 
##' @param GLMFormula 
##' @param RegularizationModel 
##' @param OutputFile Name of the output file.
microbiomeWorkflow <-
    function(CommunityFile = GalaxyInputFile(formatFilter="rda"),
             Attributes = GalaxyCharacterParam(),
             ClusteringAlgorithm = 
                GalaxyCharacterParam(c("hdist", "DirichletMultinomial")),
             DimensionalReductionMethod = GalaxyCharacterParam("MDS"),
             GLMFormula = GalaxyCharacterParam(),
             RegularizationModel =
                GalaxyCharacterParam(c("binomial", "multinomial", "gaussian")),
             OutputFile = GalaxyOutput("notimplemented", "txt"))
{
    ## all of the above
    gstop("not implemented")
}

##---------------
##' Input a CSV file of integer-valued counts of each taxon (row) in
##' each sample (column), and a CSV file of annotations
##' on each sample. The result is used in down-stream analysis.
##'
##' @title 'Community' Data Input
##' @param CountsFile Name of a CSV file containing OTU samples.
##' @param SamplesFile Name of a CSV file containing sample data.
##' @param K Include only taxa with at least K samples greater than A
##' @param A Include only taxa with at least K samples greater than A
##' @param Transform (Optional) A transformation applied to all count
##'    data, after the KOverA filter has been run. Possible values
##'    include "log" (actually, log(x + .5) to avoid logarithms of zero
##'    counts) and "asinh" (inverse hyperboloic sine, a log-like
##'    transformation with better behavior near zero).
##' @param OutputFile Name of output file
##' @return character(1); the function creates a file containing an R 
##'     'Community' instance from the 'microbiome' package. The return value
##'     is the Galaxy location in which the object is stored.
##' @examples
##' egData <- system.file(package="microbiomePkg", "extdata")
##' counts <- file.path(egData, "bv_counts.csv")
##' samples <- file.path(egData, "bv_samples.csv")
##' ccFile <- communitySlow(counts, samples)
##' ccFile
##' @import methods
##' @importMethodsFrom IRanges as.data.frame sapply nrow ncol
##' @importMethodsFrom microbiome communities communities<- normalize
##'   samples trimq
##' @importFrom grDevices dev.off pdf svg
##' @importFrom microbiome Community dendroribbons pa
##' @importFrom stats as.dendrogram dist hclust median
##'   order.dendrogram reorder
##' @importFrom utils data read.csv write.csv
##' @export
communitySlow <-
    function(CountsFile = GalaxyInputFile(formatFilter="rda"),
             SamplesFile = GalaxyInputFile(),
             K = GalaxyNumericParam(), A = GalaxyNumericParam(),
             Transform = GalaxyCharacterParam(c("none", "log", "asinh")),
             OutputFile = GalaxyOutput("community", "rda"))
{
    if (length(CountsFile) != 1L)
        gstop("'CountsFile' must be character(1): %s",
             paste(sQuote(CountsFile), collapse=", "))
    if (!file.exists(CountsFile))
        gstop("'CountsFile' does not exist: %s", sQuote(CountsFile))

    if (length(SamplesFile) != 1L)
        gstop("'SamplesFile' must be character(1): %s",
             paste(sQuote(SamplesFile), collapse=", "))
    if (!file.exists(SamplesFile))
        gstop("'SamplesFile' does not exist: %s", sQuote(SamplesFile))

    KOverA <- c(K, A)
    if (length(KOverA) != 2L || any(is.na(KOverA)))
        gstop("'K' and 'A' must be integers and not NA")

    Transform <- match.arg(Transform)

    counts <- tryCatch({
        read.csv(CountsFile, row.names=1)
    }, error = function(err) {
        gstop("'read.csv' failed to input CountsFile: %s",
             conditionMessage(err))
    })
    samples <- tryCatch({
        read.csv(SamplesFile, row.names=1)
    }, error = function(err) {
        gstop("'read.csv' failed to input SamplesFile: %s",
             conditionMessage(err))
    })

    cc <- tryCatch({
        Community(counts, samples)
    }, error = function(err) {
        gstop("'Community' instance not created: %s",
             conditionMessage(err))
    })

    ridx <- rowSums(communities(cc) >= KOverA[2]) >= KOverA[1]
    if (sum(ridx) == 0L)
        gstop("'KOverA' removed all rows")
    cc <- cc[ridx,]

    communities(cc) <-
        switch(Transform,
               none = communities(cc),
               log = log(.5 + communities(cc)),
               asinh = asinh(communities(cc)))

    save(cc, file = OutputFile)
    OutputFile
}

