##' @export
galaxify_all_microbiome <- function(galaxy_home, pkgDir, useRserve=TRUE,
    path.to.R="/home/matsenweb/R/bin")
{
    funcs <- c(
        "community",
        "getAttributeList",
        "descriptiveStatistics",
        "diversityStatistics",
        "presenceAbsence",
        "ribbonPlot",
        "reducedDimensionality",
        "cooccurrence",
        "rankAbundancePlot"
        )

    if (useRserve)
        RserveConnection <- RserveConnection(host="localhost", port=6311L)
    else
        RserveConnection <- NULL

    for (func in funcs)
    {
        cat(sprintf("Galaxifying %s()...\n", func))
        galaxify_one_microbiome(galaxy_home, pkgDir, func,
            RserveConnection=RserveConnection, path.to.R=path.to.R)
    }
    cat("Done.\n")


}

galaxify_one_microbiome <- function(galaxy_home, pkgDir,
    func, RserveConnection, path.to.R)
{
    galaxy(func,
      dirToRoxygenize=pkgDir,
      galaxyConfig=GalaxyConfig(galaxy_home, "hutch/microbiome", "Microbiome Community Analysis",
        "microbiome"), RserveConnection=RserveConnection,
        path.to.R=path.to.R)
}
