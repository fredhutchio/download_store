#' @export
galaxify_createPhyloseqObject <- function(galaxy_home, pkgDir, useRserve)
{
    galaxy(createPhyloseqObject,
        package="microbiomePkg",
        manpage="createPhyloseqObject",
        packageSourceDir=pkgDir,
        galaxyConfig=GalaxyConfig(galaxy_home, "bioc", "Bioc", "bioc"),
        useRserve=useRserve)
}


#' @export
galaxify_estimateRichness <- function(galaxy_home, pkgDir, useRserve)
{
    galaxy(estimateRichness,
        package="microbiomePkg",
        manpage="estimateRichness",
        packageSourceDir=pkgDir,
        doFilter=GalaxyParam(label="Filter OTU data?",
            checked=TRUE),
        groupBy1=GalaxyParam(required=FALSE),
        groupBy2=GalaxyParam(required=FALSE),
        galaxyConfig=GalaxyConfig(galaxy_home, "bioc", "Bioc", "bioc"),
        useRserve=useRserve)
}

#' @export
galaxify_phyloBarplot <- function(galaxy_home, pkgDir, useRserve)
{
    galaxy(phyloBarplot,
        package="microbiomePkg",
        manpage="phyloBarplot",
        packageSourceDir=pkgDir,
        galaxyConfig=GalaxyConfig(galaxy_home, "bioc", "Bioc", "bioc"),
        useRserve=useRserve)
}


#' @export
galaxify_phyloHeatmap <- function(galaxy_home, pkgDir, useRserve)
{

    galaxy(phyloHeatmap,
        package="microbiomePkg",
        manpage="phyloHeatmap",
        packageSourceDir=pkgDir,
        method=GalaxyParam(force_select=FALSE),
        distance=GalaxyParam(force_select=FALSE),
        galaxyConfig=GalaxyConfig(galaxy_home, "bioc", "Bioc", "bioc"),
        useRserve=useRserve)
}

#' @export
galaxify_ordinationPlot <- function(galaxy_home, pkgDir, useRserve)
{
    ordinationMethods <- list("DCA", "CCA", "RDA", 
        "DPCoA", "NMDS", "MDS", "PCoA")
    names(ordinationMethods) <- ordinationMethods

    galaxy(ordinationPlot,
        package="microbiomePkg",
        manpage="ordinationPlot",
        packageSourceDir=pkgDir,
        ordinationMethod=GalaxyParam(force_select=TRUE),
        color=GalaxyParam(required=FALSE),
        topN_OTUs=GalaxyParam(required=FALSE),
        topN_phyla=GalaxyParam(required=FALSE),
        galaxyConfig=GalaxyConfig(galaxy_home, "bioc", "Bioc", "bioc"),
        useRserve=useRserve)
}


##' @export
galaxify_all <- function(galaxy_home, pkgDir, useRserve)
{
    funcs <- c(
        "galaxify_estimateRichness",
        "galaxify_phyloBarplot",
        "galaxify_phyloHeatmap",
        "galaxify_ordinationPlot",
        "galaxify_createPhyloseqObject"
)
    params <- list(galaxy_home = galaxy_home, pkgDir = pkgDir,
        useRserve=useRserve)
    for (func in funcs)
    {
        cat(sprintf("Running %s...\n", func))
        do.call(func, params)
    }
    cat("Done.\n")
}
