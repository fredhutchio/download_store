## roxygenize prior to building/installing package:
## R --vanilla -e "library(roxygen2); roxygenize('microbiomePkg')" && R CMD INSTALL microbiomePkg


## TODO if version is supplied in a GalaxyParam, looks like it
## doesn't override package version. Bug or feature?

## How to get 4 data files from a phyloseq object:

# round trip, leg 1:
writeData <- function() {
    data(GlobalPatterns)
    otu <- otuTable(GlobalPatterns)
    otuMatrix <- as(otu, "matrix")

    write.csv(otuMatrix, file=system.file("extdata", "otu.csv",
        package="microbiomePkg"))
    tre <- tre(GlobalPatterns)
    write.tree(tre, file=system.file("extdata", "tre.tre",
        package="microbiomePkg"))
    samp <- sampleData(GlobalPatterns)
    df <- as(samp, "data.frame")
    write.csv(df, file=system.file("data", "sample.csv",
        package="microbiomePkg"))
    taxTab <- taxTab(GlobalPatterns)
    mTaxTab <- as(taxTab, "matrix")
    write.csv(mTaxTab, file=system.file("extdata", "taxTab.csv",
        packageSourceDir="microbiomePkg"))
}

checkValidParam <- function(param, paramName, phyloseq)
{
    validNames <- names(sampleData(phyloseq))
    if (!param %in% validNames)
    {
        msg <- sprintf(paste("Invalid value '%s' for parameter '%s'.",
            " Must be one of: %s.", sep=""), param, paramName,
            paste(validNames, collapse=", "))
        stop(msg)
    }
}


## How to get a phyloseq object from 4 data files:
# round trip, leg 2


readData <- function(otuFileName, treeFileName, taxTabFileName,
    sampleDataFileName) {
    

    otuCsv <- tryCatch({
        read.csv(otuFileName, header=TRUE, row.names=1)
    }, 
        error = function(err) {
            stop("failed to read OTU data file: ", conditionMessage(err))
    })


    tre <- tryCatch({
        read.tree(treeFileName)
    }, 
        error = function(err) {
            stop("failed to read tree file: ", conditionMessage(err))
    })

    samCsv <- tryCatch({
        read.csv(sampleDataFileName, header=TRUE, row.names=1)
    }, 
        error = function(err) {
            stop("failed to read sample data file: ", conditionMessage(err))
    })

    taxCsv <- tryCatch({
        read.csv(taxTabFileName, header=TRUE, row.names=1)
    }, 
        error = function(err) {
            stop("failed to read taxTab data file: ", conditionMessage(err))
    })
    
    ## this doesn't seem to work (talk to Martin about it):
    
    #ridx <- rownames(otuCsv) %in% rownames(taxCsv)
    #cidx <- colnames(otuCsv) %in% colnames(samCsv)
    #if (!all(ridx) || !all(cidx))
    #    warning("removing some rows / columns from otuTable")
    
    taxTab <- taxTab(as(taxCsv, "matrix"))
    #otuTable <- otuTable(otuCsv[ridx, cidx], taxa_are_rows=TRUE)
    otuTable <- otuTable(otuCsv, taxa_are_rows=TRUE)
    sampleData <- sampleData(samCsv)
    phyloseq(otuTable, tre, taxTab, sampleData)
}


## fix for broken subset


subset_species_1 <- function(physeq, i)
{
      oldMA <- as(taxTab(physeq), "matrix")
      oldDF <- data.frame(oldMA)
      newDF <- oldDF[i,,drop=FALSE]
      newMA <- as(newDF, "matrix")
      if (class(physeq) == "taxonomyTable") {
          return(taxTab(newMA))
      }
      else {
          taxTab(physeq) <- taxTab(newMA)
          return(physeq)
      }
}



# generate the man page like this:
# if working directory contains microbiomePkg:
# library(roxygen2)
# roxygenize("microbiomePkg")


#' Create a phyloseq object
#'
#' Takes files and returns a phyloseq object.
#' @param otuFileName The name of a CSV file containing OTU samples
#' @param treeFileName The name of a .tre file
#' @param taxTabFileName The name of a CSV file containing a taxonomy table
#' @param sampleDataFileName The name of a CSV file containing sample data
#' @param phyloseqfile The name of the output data file
#' @export
createPhyloseqObject <- function(otuFileName=GalaxyInputFile(),
    treeFileName=GalaxyInputFile(),
    taxTabFileName=GalaxyInputFile(), 
    sampleDataFileName=GalaxyInputFile(),
    phyloseqfile=GalaxyOutput("phyloseq_data", "rda"))
{
    phyloseq <- readData(otuFileName, treeFileName,
        taxTabFileName, sampleDataFileName)
    save(phyloseq, file=phyloseqfile)
}

#' Generate richness estimates.
#'
#' This function returns phylogenetic richness estimates and
#' a phylogenetic richness plot.
#'
#' @details This tool returns two items, a CSV file containing
#' richness estimates, and a PDF containing a plot of 
#' the richness estimates.
#'
#' @param phyloseqfile A phyloseq data file
#' @param plotFileName The filename of a PDF plot to be generated
#' @param richnessCsvFileName The filename of a CSV file to be generated
#' @param doFilter whether to filter out species which are 
#'  not represented at all in a given row
#' @param groupBy1 Optional. A variable to map the horizontal axis of the
#' estimated richness plot
#' @param groupBy2 Optional. The sample variable to map to different
#' colors in the estimated richness plot.
#' @export

estimateRichness <- function(phyloseqfile=GalaxyInputFile(),
    plotFileName=GalaxyOutput("richness_plot", "pdf"),
    richnessCsvFileName=GalaxyOutput("richness_estimates", "csv"),
    doFilter=TRUE, groupBy1=character(), groupBy2=character())
{
    load(phyloseqfile)
    
    my_filter_taxa <-
    function (physeq, flist, prune = FALSE) 
    {
        OTU <- otuTable(physeq)
        if (!speciesAreRows(OTU)) {
            OTU <- t(OTU)
        }
        ans <- apply(OTU, 1, flist)
        if (prune) {
            return(prune_species(ans, physeq))
        }
        else {
            return(ans)
        }
    }
    
        
    if(doFilter) {
        flist <- filterfun(kOverA(1, .Machine$double.xmin), allNA)
        pruneMe <- my_filter_taxa(phyloseq, flist)
        phyloseq <- prune_species(pruneMe, phyloseq)
    }
    
    richness <- estimate_richness(phyloseq)
    write.csv(richness, file=richnessCsvFileName)


    pdf(plotFileName)
    params <- list()
    params$physeq <- phyloseq
    
    if(!missing(groupBy1)) {
        checkValidParam(groupBy1, "groupBy1", phyloseq)
        params$x = groupBy1
    }
    if(!missing(groupBy2)) {
        checkValidParam(groupBy2, "groupBy2", phyloseq)
        params$color = groupBy2        
    } 
    p <- do.call(plot_richness_estimates, params)
    print(p)
    dev.off()
    
}

#' Generate a barplot
#'
#' Generate a rank-abundance barplot.
#'
#'
#' @param phyloseqfile A phyloseq data file
#' @param numOTUs number of OTUs to plot
#' @param plotFileName The name of the PDF plot to generate
#' @export
phyloBarplot <- function(phyloseqfile=GalaxyInputFile(), 
    numOTUs=30L, plotFileName=GalaxyOutput("rank_abundance_barplot", "pdf"))
{
    load(phyloseqfile)
    pdf(plotFileName)
    par(mar = c(10, 4, 4, 2) + 0.1) # make more room on bottom margin
    barplot(sort(speciesSums(phyloseq),
        TRUE)[1:numOTUs]/nsamples(phyloseq), las=2)
    dev.off()
}



#' Generate a heatmap
#'
#' Generate an exploratory heatmap
#'
#'
#' @param phyloseqfile A phyloseq data file
#' @param numOTUs number of OTUs to plot
#' @param plotFileName The name of the PDF plot to generate
#' @export
phyloHeatmap <- function(phyloseqfile=GalaxyInputFile(), numOTUs=200L,
    method=c("None", "DCA", "CCA", "RDA", 
        "DPCoA", "NMDS", "MDS", "PCoA"),
    distance=as.character(c("None", phyloseq::distance("list"))),
    plotFileName=GalaxyOutput("phyloseq_heatmap", "pdf")) 
{

    load(phyloseqfile)
    
    params <- list()
    if (!method == "None")
    {
        if (!method %in% c("DCA", "CCA", "RDA", "DPCoA", "NMDS", 
            "MDS", "PCoA"))
            stop("Invalid ordination method!")
        params$method <- method
    }

    if (!distance == "None")
    {
        if (!distance %in% phyloseq::distance("list"))
            stop("Invalid distance method!")
        params$distance <- distance
    }
    
    
    # trim
    topsp <- names(sort(speciesSums(phyloseq), TRUE)[1:numOTUs])
    idx <- rownames(taxtab(phyloseq)) %in% topsp
    phyloseq <- subset_species_1(phyloseq, idx)

    params$physeq = phyloseq

    pdf(plotFileName)
    
    p <- do.call(plot_heatmap, params)
    print(p)
    dev.off()
}


#' Generate ordination plot
#'
#' Generate an ordination plot
#'
#' @details This function can take some time to run on a full dataset,
#' so it is recommended that you plot only a subset of your data. Here
#' you can choose the top N OTUs and top N species that your plot
#' will be generated from.
#'
#' @param phyloseqfile A phyloseq data file
#' @param topN_OTUs Filter by this many most abundant OTUs
#' @param topN_phyla Filter by this many most abundant phyla
#' @param ordinationMethod Ordination Method to use
#' @param color Color by this sample column and include a legend
#' @param plotFileName The name of the PDF plot to generate
#' @export
ordinationPlot <- function(phyloseqfile=GalaxyInputFile(),
    topN_OTUs=200L, topN_phyla=5L,
    ordinationMethod=c("DCA", "CCA", "RDA", 
        "DPCoA", "NMDS", "MDS", "PCoA"),
    color=character(), plotFileName=GalaxyOutput("ordination_plot", "pdf"))
{
    params <- list()

    if (!missing(color))
    {
        checkValidParam(color, "color", phyloseq)
        params$color = color
    }

    load(phyloseqfile)
    
    if (!missing(topN_OTUs))
    {
        topsp <- names(sort(speciesSums(phyloseq), TRUE)[1:topN_OTUs])
        idx <- rownames(taxtab(phyloseq)) %in% topsp
        phyloseq <- subset_species_1(phyloseq, idx)
        
    }
    
    if (!missing(topN_phyla))
    {
        topph <- sort(tapply(speciesSums(phyloseq),
            taxTab(phyloseq)[, "Phylum"], sum), decreasing=TRUE)[1:topN_phyla]
        m <- as(taxTab(phyloseq), "matrix")
        d <- data.frame(m)
        idx <- d$Phylum %in% names(topph)
        phyloseq <- subset_species_1(phyloseq, idx)
    }
    
    
    params$physeq = phyloseq

    ord <- ordinate(phyloseq, ordinationMethod)
    params$ordination <- ord

    pdf(plotFileName)
    
    ## params$color <- "SampleType" ## depends on what columns are in phyloseq
    p <- do.call(plot_ordination, params)
    print(p)
    dev.off()
}

