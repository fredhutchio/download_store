diversityStatistics <-
    function(x, statistics=c("Shannon", "Simpson", "Chao1", "ACE"))
{
    formals <- as.character(formals()[["statistics"]])
    if (any(idx <- !statistics %in% formals))
        stop(sprintf("invalid 'statstics' value(s): '%s'",
                     paste(statistics[idx], collapse=", ")))
    smap <- list(Shannon="Shannon", Simpson="Simpson",
                 Chao1=c("Chao1", "Chao1.SE"), ACE=c("ACE", "ACE.SE"))
    statistics <- unlist(smap[statistics], use.names=FALSE)

    m <- t(communities(x))
    diversity <- vegan::diversity
    df0 <- data.frame(NTaxa=rowSums(m!=0),
                      NReads=rowSums(m),
                      Shannon=diversity(m, "shannon"),
                      Simpson=diversity(m, "simpson"),
                      row.names=rownames(m))
    df1 <- as.data.frame(t(vegan::estimateR(m)))[,-1]
    map <- c(S.chao1="Chao1", se.chao1="Chao1.SE", S.ACE="ACE",
             se.ACE="ACE.SE")
    names(df1) <- map[names(df1)]

    ## return only those requested
    df <- .mmerge(df0, df1)
    df[, match(c("NTaxa", "NReads", statistics), names(df))]
}
