setClass("Community", contains="DataFrame")

Community <-
    function(community=matrix(0L, 0L, 0L), samples=data.frame(), ...,
             verbose=TRUE)
{
    if (!is.matrix(community))
        community <- as.matrix(community)
    if (mode(community) != "numeric")
        .stopf("'community' must contain 'numeric' data, but contained %s",
               sQuote(mode(community)))
    id <- intersect(rownames(samples), colnames(community))
    if (verbose) {
        if (length(id) != nrow(samples)) {
            txt <- "%d of %d 'samples' rows consistent with 'community'"
            smessage(txt, length(id), nrow(samples), call.=FALSE)
        }
        if (length(id) != ncol(community)) {
            txt <- "%d of %d 'community' columns consistent with 'samples'"
            smessage(txt, length(id), ncol(community), call.=FALSE)
        }
    }
    
    community <- community[,match(id, colnames(community))]
    samples <- samples[match(id, rownames(samples)),]
    df <- as(community, "DataFrame")
    elementMetadata(df) <- as(samples, "DataFrame")
    new("Community", df)
}

setMethod("samples", "Community",
    function(x, ...)
{
    elementMetadata(x)
})

setReplaceMethod("samples", c("Community", "data.frame"),
    function(x, ..., value) 
{
    elementMetadata(x) <- value
    x
})

setReplaceMethod("samples", c("Community", "DataFrame"),
    function(x, ..., value) 
{
    elementMetadata(x) <- value
    x
})

setMethod(communities, "Community",
    function(x, ...)
{
    v <- unlist(lapply(x, as.vector))
    m <- matrix(v, ncol=ncol(x))
    dimnames(m) <- dimnames(x)
    m
})

setReplaceMethod("communities", c("Community", "matrix"),
    function(x, ..., value)
{
    x[] <- as(value, "DataFrame")
    x
})

setMethod(normalize, "Community",
    function(x, byTaxon="none", bySample=c("none", "median"),
             transform=c("none", "asinh"))
{
    v <- communities(x)
    v <- switch(match.arg(byTaxon), none=v)
    v <- switch(match.arg(bySample), none=v,
                median={
                    m <- colMeans(v)
                    ceiling(v * median(m) / rep(m, each=nrow(v)))
                })
    v <- if (is.function(transform)) transform(v)
    else switch(match.arg(transform), none=v, asinh=asinh(v))
    x[] <- as(v, "DataFrame")
    x
})

setMethod(trimq, "Community",
    function(x, taxonQ=0, sampleQ=0, ...)
{
    cc <- communities(x)
    i <- j <- TRUE
    if (0 != taxonQ)
        i <- rowSums(cc) > quantile(rowSums(cc), taxonQ)
    if (0 != sampleQ)
        j <- colSums(cc) > quantile(colSums(cc), sampleQ)
    x[i, j]
})

setMethod(xtabs, c(data="Community"),
    ## FIXME: not all arguments supported
    ## FIXME: 'count' is allowed on the LHS of formula
    function (formula = ~., data = parent.frame())
{
    df <- as(samples(data), "data.frame")
    cc <- communities(data)
    lst <- lapply(seq_len(nrow(cc)), function(i, formula, cc, df, ...) {
        ## fit the model
        data <- cbind(df, count=cc[i,])
        as.data.frame(xtabs(formula, data, ...))
    }, formula, cc, df)
    nm <- rep(rownames(data), times=sapply(lst, nrow))
    df <- cbind(Name=nm, do.call(rbind, lst))
    rownames(df) <- NULL
    as(df, "DataFrame")
})

setMethod(show, "Community",
    function(object)
{
    wrapcat <- function(..., collapse=" ") {
        txt <- strwrap(paste(c(...), collapse=collapse), exdent=2)
        cat(paste(txt, collapse="\n"), "\n")
    }
    cat("class:", class(object), "\n")
    cat("dim:", dim(object), "\n")
    wrapcat("taxa:", BiocGenerics:::selectSome(rownames(object)))
    wrapcat("samples:", BiocGenerics:::selectSome(names(object)))
})
