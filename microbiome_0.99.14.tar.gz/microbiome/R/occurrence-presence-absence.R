occur <-
    function(x, group, ..., threshold)
{
    group <- samples(x)[[group]]
    cc <- communities(x)
    if (!missing(threshold))
        cc <- cc >  threshold
    res <- t(apply(cc, 1, function(counts, group) {
        xtabs(counts~group)
    }, group=group))
    rownames(res) <- rownames(x)
    res
}

pa <-
    function(x, group, ...)
{
    keep <- !is.na(samples(x)[[group]])
    if (sum(keep) == 0)
        stop("group ", sQuote(group), " has no non-missing values")
    x <- x[,keep]
    res <- occur(x, group, ..., threshold=0L)
    group <- samples(x)[[group]]
    n <- table(group)
    p <- n / sum(n)
    withCallingHandlers({
        chisq <- lapply(seq_len(nrow(res)), function(i, res, p) {
            x <- res[i,]
            if (all(x <= 0))
               c(statistic=NA, p.value=NA)
            else
                chisq.test(res[i,], p=p)
        }, res=res, p=p)
    }, warning = function(warn) {
        if ("chisq.test" == as.character(conditionCall(warn)[[1]]))
            invokeRestart("muffleWarning")
        else warn
    })
    chisq.stat <-unname(sapply(chisq, "[[", "statistic"))
    p <- unname(sapply(chisq, "[[", "p.value"))
    as(cbind(res, Chisq=chisq.stat, P=p), "DataFrame")
}
