smessage <-
    function(...)
{
    message("microbiome: ", sprintf(...))
}

.stopf <-
    function(fmt, ..., call.=FALSE)
{
    stop("microbiome: ", sprintf(fmt, ...), call.=call.)
}

.ullapply <-
    function(X, ELT)
{
    unlist(lapply(X, lapply, "[[", ELT), use.names=FALSE)
}

.mmerge <-
    function(...)
{
    x <- merge(..., by=0)
    row.names(x) <- x[["Row.names"]]
    x[["Row.names"]] <- NULL
    x
}
