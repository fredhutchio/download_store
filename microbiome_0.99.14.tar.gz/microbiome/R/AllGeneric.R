setGeneric("samples", function(x, ...) standardGeneric("samples"))

setGeneric("communities", function(x, ...)
           standardGeneric("communities"))

setGeneric("samples<-",
    function(x, ..., value) standardGeneric("samples<-"))

setGeneric("communities<-",
    function(x, ..., value) standardGeneric("communities<-"))

setGeneric("normalize", function(x, ...) standardGeneric("normalize"))

setGeneric("trimq", function(x, ...) standardGeneric("trimq"))

setGeneric("heatplot", function(x, ...) standardGeneric("heatplot"))
