glmFit <-
    function(formula, x, ..., FUN=glm.nb)
{
    df <- as(samples(x), "data.frame")
    cc <- communities(x)
    res <- lapply(seq_len(nrow(cc)), function(i, formula, cc, df, ...) {
        ## FIXME provide reasonable estimates for theta, mu 
        data <- cbind(df, count=cc[i,])
        tryCatch(FUN(formula, data, ...),
                 error=function(err) { warning(err); NULL })
    }, formula, cc, df, ...)
    names(res) <- rownames(x)
    if (length(res) == 1)
        SimpleList(res)
    else
        do.call(SimpleList, res)
}

glmSummary <-
    function(fit, ...)
{
    res <- lapply(fit, function(x) {
        if (is.null(x)) return(x)
        coef <- coefficients(summary(x))
        switch(class(x)[1],
               negbin=c(
                 Est=coef[nrow(coef), 1],
                 P=coef[nrow(coef), 4]),
               hurdle=,
               zeroinfl=c(
                 Est.Zero=coef[["zero"]][nrow(coef[["zero"]]), 1],
                 Est.Count=coef[["count"]][nrow(coef[["count"]]), 1],
                 P.Zero=coef[["zero"]][nrow(coef[["zero"]]), 4],
                 P.Count=coef[["count"]][nrow(coef[["count"]]), 4]),
           {
               warning("'", class(x)[1], "' unhandled")
               NULL
           })
    })
    valid <- Filter(Negate(is.null), res)
    tmpl <- valid[[1]]
    tmpl <- structure(rep(NA, length(tmpl)), .Names=names(tmpl))
    res <- Map(function(x, tmpl) if (is.null(x)) tmpl else x, res,
               MoreArgs=list(tmpl))
    as.data.frame(t(simplify2array(res)))
}
