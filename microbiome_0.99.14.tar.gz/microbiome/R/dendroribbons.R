dendroribbons <-
    function(ddr, data, colschm=brewer.pal(9, "OrRd"),
             dheight=.2, dwidth=.8, colmissing="lightgrey",
             main=character())
{
    layout(matrix(c(1, 2, 0, 0), ncol=2L),
           heights=c(dheight, 1.-dheight),
           widths=c(dwidth, 1.-dwidth))

    colfun <- colorRampPalette(colschm)
    img <- sapply(rev(data), function(elt) {
        i <- as.factor(elt)
        col <- colfun(length(levels(i)))[i]
        col[is.na(i)] <- colmissing
        col
    })
    col <- levels(factor(img))
    mode(img) <- "factor"
    dimnames(img) <- list(rownames(data), rev(names(data)))

    opar <- par(mar = c(0, .5, 1, .5))
    on.exit(par(opar))
    switch(class(ddr), hclust={
        plot(ddr, labels=FALSE, axes = FALSE, xaxs = "i", ann=FALSE,
             hang=0.02)
    }, phylo={
        plot.phylo(ddr, show.tip.label=FALSE, no.margin=TRUE,
                   direction="downwards")
    }, {
        plot(ddr, axes = FALSE, xaxs = "i", leaflab = "none")
    })
    title(main=main)
    par(mar = c(0, .5, 0, .5))
    image(img, col=col, axes=FALSE)
    at <- (seq_len(ncol(img)) - 1) / (ncol(img) - 1)
    axis(4, at=at, labels=colnames(img), las=2)
}
