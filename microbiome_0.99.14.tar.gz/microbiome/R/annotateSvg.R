.mds_script <- I("
function makeLabel(elementId, x, y, id, value)
{
    xmlns = 'http://www.w3.org/2000/svg';
    lbl = document.createElementNS(xmlns, 'text');
    lbl.setAttribute('x', x);
    lbl.setAttribute('y', y);
    lbl.setAttribute('id', id);
    lbl.setAttribute('style', 'font-family:sans-serif; font-size:11px');
    lbl.appendChild(document.createTextNode(value));
    document.getElementById(elementId).appendChild(lbl);
}
function setLabels(specimen, covariate, value)
{
    specimen = specimen || 'Specimen';
    covariate = covariate || '';
    value = value || '';
    document.getElementById('selectedId').childNodes[0].
    nodeValue = specimen;
    document.getElementById('covariateId').childNodes[0].
    nodeValue = covariate;
    document.getElementById('covariateValue').childNodes[0].
    nodeValue = value;
}
function LoadSvg()
{
    lbl = makeLabel('surface0', '360', '70', 'covariateId', '')
    lbl = makeLabel('surface0', '360', '70', 'selectedId',
       'Specimen')
    lbl = makeLabel('surface0', '360', '82', 'covariateValue', '')
}
function SelectSample(evt)
{
    id = evt.target.getAttribute('id');
    sid = plotData.covariates['specimen'][id];
    setLabels(sid, null,
              plotData.covariates[plotData.covariateName][id]);
}
function DeselectSample(evt)
{
    setLabels()
}
")

annotateMds <-
    function(fl, data, group, dest=fl)
{
    if (!suppressWarnings(require(SVGAnnotation)))
        stop("package 'SVGAnnotation' not installed")
    grp <- data[[group]]
    xml <- SVGAnnotation::xmlPlot(fl)
    covariates <- list(rownames(data), data[[group]])
    names(covariates) <- c("specimen", group)
    SVGAnnotation::addECMAScripts(xml, .mds_script,
        plotData = list(sampleNames=rownames(data),
                        covariateName=as.character(group),
                        covariates=lapply(covariates, as.character)),
        at=1)
    ## xquery <- "//*[@id='surface0']"
    xquery <- "//x:g[@clip-path][7]"
    node <- XML::getNodeSet(xml, xquery, "x")[[1]]
    XML::xmlAttrs(node)[["onload"]] <- "LoadSvg()"
    XML::xmlAttrs(node)[["onmouseover"]] <- "SelectSample(evt)"
    XML::xmlAttrs(node)[["onmouseout"]] <- "DeselectSample(evt)"

    xquery <- "//x:g[@clip-path][7]/x:path"
    nodes <- XML::getNodeSet(xml, xquery, "x")
    idx <- unlist(split(seq_along(grp), grp), use.names=FALSE) - 1L
    for (i in seq_along(nodes))
        XML::xmlAttrs(nodes[[i]])[["id"]] = idx[i]

    XML::saveXML(xml, dest)
}

.dendroribbon_script <- I("
function makeLabel(elementId, x, y, id, value)
{
    xmlns = 'http://www.w3.org/2000/svg';
    lbl = document.createElementNS(xmlns, 'text');
    lbl.setAttribute('x', x);
    lbl.setAttribute('y', y);
    lbl.setAttribute('id', id);
    lbl.setAttribute('style', 'font-family:sans-serif; font-size:11px');
    lbl.appendChild(document.createTextNode(value));
    document.getElementById(elementId).appendChild(lbl);
}
function setLabels(specimen, covariate, value)
{
    specimen = specimen || 'Subject / Specimen';
    covariate = covariate || 'Covariate';
    value = value || '';
    document.getElementById('selectedId').childNodes[0].
    nodeValue = specimen;
    document.getElementById('covariateId').childNodes[0].
    nodeValue = covariate;
    document.getElementById('covariateValue').childNodes[0].
    nodeValue = value;
}
function LoadSvg()
{
    var w = document.getElementById('surface0').getBBox().width
    lbl = makeLabel('surface0', .8 * w, '70', 'selectedId', 'Specimen');
    lbl = makeLabel('surface0', .8 * w, '82', 'covariateId', 'Covariate');
    lbl = makeLabel('surface0', .8 * w, '94', 'covariateValue', '');
}
function SelectSample(evt)
{
    bbox = evt.target.getBBox();
    pbox = evt.target.parentNode.getBBox();
    len = sampleNames.length;
    i = Math.floor(len * (bbox.x + bbox.width / 2 - pbox.x) / pbox.width);
    len = covariateNames.length;
    j = Math.floor(len * (bbox.y + bbox.height / 2 - pbox.y) / pbox.height);
    covName = covariateNames[j];
    setLabels(sampleNames[i], covName, covariates[covName][i]);
}
function DeselectSample(evt)
{
    setLabels();
}
")

annotateDendroribbon <- 
    function(fl, data, dest=fl)
{
    if (!suppressWarnings(require(SVGAnnotation)))
        stop("package 'SVGAnnotation' not installed")
    xml <- xmlPlot(fl)
    SVGAnnotation::addECMAScripts(xml, .dendroribbon_script,
        sampleNames=rownames(data), covariateNames=names(data),
        covariates=lapply(data, as.character),
        at=1)
    ## xquery <- "//*[@id='surface0']"
    xquery <- "//x:g[@clip-path]"
    nodes <- XML::getNodeSet(xml, xquery, "x")
    XML::xmlAttrs(nodes[[2]])[["onload"]] <- "LoadSvg()"
    XML::xmlAttrs(nodes[[2]])[["onmouseover"]] <- "SelectSample(evt)"
    XML::xmlAttrs(nodes[[2]])[["onmouseout"]] <- "DeselectSample(evt)"
    XML::saveXML(xml, dest)
}
