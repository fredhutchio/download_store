cooccurplot <-
    function(x, ..., lbl=rownames(x), distfun=dist,
             hclustfun=function(...) hclust(..., method="average"),
             method="pearson", text.cex=1,
             colschm=brewer.pal(8, "OrRd"))
{
    colschm <- brewer.pal(8, "OrRd")
    x <- cor(t(communities(x)), method=method)
    ridx <- order.dendrogram(reorder(as.dendrogram(hclustfun(distfun(x))),
                                     rowMeans(x, na.rm=TRUE)))
    cidx <- order.dendrogram(reorder(as.dendrogram(hclustfun(distfun(x))),
                                     colMeans(x, na.rm=TRUE)))

    ## diag(x) <- max(lower.tri(x)*x)
    x[ridx, cidx][upper.tri(x, TRUE)] <- NA

    s <- seq_len(nrow(x))
    n <- length(s) - 1
    opar <- par(mar=c(0, 0, 0, 0), bty="n")
    on.exit(par(opar))
    lim <- c(-0.05, 1.35)
    image(x[ridx,cidx][rev(s),], col=brewer.pal(8, "OrRd"),
          xlim=lim, ylim=lim, asp=1, xaxt="n", yaxt="n", ann=FALSE)
    text((s - 1) / n, rev(s - 1) / n, labels=rev(lbl[ridx]),
         adj=c(0, .5), srt=45, cex=text.cex)
    lgnd <- levels(cut(x, length(colschm)))
    lgnd <- sapply(strsplit(gsub("(\\(|\\])", "", lgnd), ","),
                   function(x) {
                       x = as.numeric(x)
                       sprintf(fmt="% .2f - % .2f", x[[1]], x[[2]])
                   })
    legend("topright", lgnd, title="Correlation", fill=colschm,
           bty="n", bg="white", inset=c(.05, .05), title.adj=0)
}

cooccurplot.orig <-
    function(x, ..., legendCex=1, distfun=dist,
             hclustfun=function(...) hclust(..., method="average"),
             method="pearson",
             main="Correlation (light: negative; dark: postiive)",
             colschm=brewer.pal(8, "OrRd"),
             margins=c(10, 10))
{
    x <- cor(t(communities(x)), method=method)
    ridx <- order.dendrogram(reorder(as.dendrogram(hclustfun(distfun(x))),
                                     rowMeans(x, na.rm=TRUE)))
    cidx <- order.dendrogram(reorder(as.dendrogram(hclustfun(distfun(x))),
                                     colMeans(x, na.rm=TRUE)))

    diag(x) <- max(lower.tri(x)*x)
    ## x[ridx, cidx][upper.tri(x, TRUE)] <- NA
    heatmap(x[ridx, cidx], Rowv=NA, Colv=NA, ..., symm=TRUE,
            distfun=distfun, hclustfun=hclustfun,
            col=colschm, main=main, margins=margins)
    lgnd <- levels(cut(x, length(colschm)))
    lgnd <- sapply(strsplit(gsub("(\\(|\\])", "", lgnd), ","),
                   function(x) {
                       x = as.numeric(x)
                       sprintf(fmt="%.2f - %.2f", x[[1]], x[[2]])
                   })
    opar <- par(mar=c(0, 0, 0, 0))
    on.exit(par(opar))
    legend(.8, .1, lgnd, title="Correlation", title.adj=0,
           fill=colschm, box.lwd=0, cex=legendCex, bg="white")
}
